import os,sys 

# os._exit(0)
sys.exit("进程退出")
print("Process exit")
def get_infos():
    L=[]
    while True:
        a=input("请输入姓名")
        if not a:
            break
        b=int(input("请输入年龄"))
        c=input("请输入家庭住址")
        L.append(dict(name=a,age=b,address=c))
    return L
def save_to_file(L):
    try:
        f=open("infos.txt",'w')
        print("打开文件成功")
        for d in L:
            f.write(d['name'])
            f.write(' ')
            f.write(str(d['age']))
            f.write(' ')
            f.write(d['address'])
            f.write('\n')
        f.close()
        print("文件关闭成功")
    except OSError:
        print("打开文件失败")


def read_fro_file():
    L=[]
    try:
        f=open("infos.txt",'r')
        while True:
            line=f.readline()
            if not line:
                break
            line=line.rstrip()
            items=line.split()
            d=dict(name=itmes[0],age=int(items[1]),address=items[2])
            L.append(d)
        f.close()
        print("读取文件成功")
    except OSError:
        print("打开文件失败")
def print_infos(L):


    print(L)

L=get_infos()
print(L)
save_to_file(L)
read_fro_file()
print_infos(L)




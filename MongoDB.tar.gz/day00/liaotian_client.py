from socket import *

sockfd = scoket(AF_)

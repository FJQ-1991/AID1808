import student_info as st
from menu import show_menu 
def main():
    i=[]
    while True:
        show_menu()
        s = input('请选择: ')
        if s == '1':
            i +=st.input_student()
        elif s == '2':
            st.print_student(i)
        elif s=='3':
            st.shanchu(i)
        elif s=='4':
            st.xiugai(i)
        elif s=='5':
            st.chengji(i)
        elif s=='6':
            st.digao(i)
        elif s=='7':
            st.nianling_gao(i)
        elif s=='8':
            st.nianling_di(i)
        elif s == 'q':
            break
main()
def input_student():
    L=[]
    while True:
        d={}
        global score,name
        a =input('请输入姓名：')
        if a=='':        
            break
        else:
            d['name']=a
        try:
            c=int(input('请输入成绩：'))
            b=int(input('请输入年龄：'))
        except:
            print("您的输入有误，请重新输入：")
            continue
        import copy
        d['age']=b
        d['score']=c
        L.append(d)
    return L

def print_student(e):
    m='+'+'-'*10+'+'+'-'*10+'+'+'-'*10+'+'
    print(m) 
    print('|'+'name'.center(10)+'|'+'age'.center(10)+'|'+'score'.center(10)+'|')
    print(m) 
    for x in e:
        n='|'+x['name'].center(10)+'|'+str(x['age']).center(10)+'|'+str(x['score']).center(10)+'|'
        print(n) 
        print(m)

def shanchu(L):
    i=0
    while i<len(L):
        print(L[i])
        n=input("请选择yes或no: ")
        if n == 'yes':
            L.remove(L[i])
        if n== 'no':
            i +=1
            continue
    return L 
def xiugai(L):
    for x in L:
        print(x)
        n=input("请选择yes或no: ")
        if n == 'yes':
            L.remove(x)
            x=input_student()
        if n == 'no':
            continue
    return L
def chengji(L):
    def get_score(d):
        return d['score']
    L=sorted(L,key=get_score,reverse=True)
    print_student(L)


def digao(L):
    L=sorted(L,key=lambda d:d['score'])
    print_student(L)

def nianling_gao(L):
    L=sorted(L,key=lambda d:d['age'],reverse=True)
    print_student(L)

def nianling_di(L):
    L=sorted(L,key=lambda d:d['age'])
    print_student(L)


# 此示例示意类变量的定义方法和用法
# class Car:
#     # 类变量，用于保存汽车对象的个数
#     total_count=0       # 创建类变量
# print(Car.total_count)    # 读取类变量的值
# Car.total_count +=100    # 修改类变量
# print(Car.total_count)   # 100

# c1=Car()
# print(c1.total_count)   # 100借助对象访问类变量
# c1.total_count=999   # 999  创建实例变量
# print(c1.total_count)
# print(Car.total_count)   # 100

# #类变量可以通过此类的对象的__class__属性间接访问
# c1.__class__.total_count=8888
# print(c1.total_count)  # 999
# print(Car.total_count)  #8888

# class Car:
#     # 类变量，用于保存汽车对象的个数
#     total_count=0       # 创建类变量
#     def __init__(self,info):
#         self.info=info
#         print("汽车",info,"被创建")
#         self.__class__.total_count +=1
#     def __del__(self):
#         print("汽车",self.info,"被销毁")
#         self.__class__.total_count -=1
# c1=Car("BYD E6")
# c2=Car("吉利　E7")
# print("当前有%d个汽车对象"%Car.total_count)    #  2
# del c2
# print(Car.total_count)    # 1
 
# 此示例示意类内的__slots__列表的用法
# class Human:
#     # 限制Human类的对象只能有"name",和"age"属性，不能有其它属性
#     __slots__=["name","age"]
#     def __init__(self,n,a):
#         self.name,self.age=n,a
#     def show_info(self):
#         print(self.name,self.age)

# s1=Human("Tarena",15)
# s1.show_info()
# s1.Age=16      #  报错
# s1.show_info()

# 此示例示意类方法的定义及调用
# class A:
#     v=0
#     @classmethod
#     def get_v(cls):
#         return cls.v    # 获取类变量v的值

#     @classmethod
#     def set_v(cls,value):
#         cls.v=value    # 设置类变量v=value

# print(A.v)    #  0 直接访问类变量
# value=A.get_v()     #  相调用A类的方法来取值
# print("value=",value)    # 0
# A.set_v(999)
# print(A.get_v())    # 999
  
# 此示例示意静态方法的定义和使用
# class A:
#     @staticmethod
#     def myadd(a,b):
#         '''这是静态方法'''
#         return a+b
# # 用类来调用静态方法
# print(A.myadd(100,200))    # 300
# a=A()
# # 用此类的实例来调用静态方法
# print(a.myadd(300,400))    # 700

# 1.用来描述一个学生的信息（可以修改之前写的Student类）

# class Student:
#     global L1,L2,L3
#     L1=[]
#     L2=[]
#     L3=[]
#     def __init__(self,n,a,s):
#         self.name=n 
#         self.age=a 
#         self.score=s
#         L1.append(self.name)
#         L2.append(self.age)
#         L3.append(self.score)
#     @staticmethod
#     def tianjia():
#         while True:
#             n=input("请输入学生姓名：")
#             if not n:
#                 break   
#             a=int(input("请输入学生年龄："))
#             s=int(input("请输入学生成绩："))
#             Student(n,a,s)
# j=Student.tianjia()
# print("学生的个数是：",len(L1))
# print("学生的平均成绩是：",int(sum(L3))/len(L3))
# print("学生的平均年龄是:",int(sum(L2))/len(L2))
# 学生信息有：
#     姓名，年龄，成绩
# 将这些学生对象存于列表中，可以任意添加和删除学生信息
#     １）打印出学生的个数
#     ２）打印出所有学生的平均成绩
#     ３）打印出所有学生的平均年龄
#     （建议用列表的长度来计算学生的个数）        

# class Human:
#     '''此类用于描述人类的共性'''
#     def say(self,what):
#         print("说",what)
#     def walk(self,distance):
#         print("走了",distance,"公里")
# class Student(Human):
#     def study(self,subject):
#         print("正在学习",subject)
# class Teacher(Student):
#     def teach(self,subject):
#         print("正在教",subject)

# h1=Human()
# h1.say("天真蓝")
# h1.walk(5)

# s1=Student()
# s1.say("学习有点累")
# s1.walk(1)
# s1.study("Python")

# t1=Teacher()
# t1.study("魔方")
# t1.teach("继承／派生")
# t1.say("终于要放假了")
# t1.walk(3)

# 此示例示意覆盖的语法
# class A:
#     def work(self):
#         print("A.work被调用")
# class B(A):
#     def work(self):
#         '''此方法会覆盖父类的work方法'''
#         print("B.work被调用")
# b=B()
# b.work()    # B.work被调用
# a=A()
# a.work()    # A.work被调用
# A.work(b)   # 通过B间接调用A

# 此示例示意用super函数显式的调用被覆盖的方法
# class A:
#     def work(self):
#         print("A.work被调用")
# class B(A):
#     def work(self):
#         '''此方法会覆盖父类的work方法'''
#         print("B.work被调用")
#     def mywork(self):
#         #调用自己（B类）的方法
#         self.work()
#         # 调用父类（A类）的方法
#         super(B，self).work()
# b=B()
# b.work()    # B.work被调用
# a=A()
# a.work()    # A.work被调用
# super(B，b).work()   #A.work被调用
# b.mywork()

class Human:
    def __init__(self,n,a):
        self.name=n
        self.age=a
        print("Human.__init__被调用")
    def show_info(self):
        print("姓名：",self.name)
        print("年龄:",self.age)
class Student(Human):
    def __init__(self,n,a,s=0):
        super(Student,self).__init__(n,a)
        self.score=s
        print("Student.__init__被调用")
    def show_info(self):
        super().show_info()
        print("成绩：",self.score)
s=Student("小张",20,100)
s.show_info()






























































# class Shape:
#     def draw(self):
#         print("Shape.draw被调用")
# class Point(Shape):
#     def draw(self):
#         print("Point.draw被调用")
# class Circle(Point):
#     def draw(self):
#         print("Circle.draw被调用")
# def my_draw(s):
#     s.draw()    # 此处显示出多态中的动态
# s1=Circle()
# s2=Point()
# my_draw(s2)
# my_draw(s1)
# s3=Shape()
# my_draw(s3)

# class Car:
#     def run(self,speed):
#         print("汽车以",speed,"km/h的速度行驶")
# class Plane:
#     def fly(self,height):
#         print("飞机以海拔",height,"米高度飞行")
# class PlaneCar(Car,Plane):
#     """Plane Car类同时继承自汽车类和飞机类""" 
# p1=PlaneCar()
# p1.fly(10000)
# p1.run(300)

#　小张写了一个类A
# class A:
#     def m(self):
#         print("A.m()被调用")
# # 小王写了一个类B
# class B:
#     def m(self):
#         print("B.m()被调用")
# #小王感觉小张和小王写的两个类自己都能用
# class AB(A,B):
#     pass
# ab=AB()
# ab.m()

# class A:
#     def go(self):
#         print("A")
# class B(A):
#     def go(self):
#         print("B")
#         super().go()
# class C(A):
#     def go(self):
#         print("C") 
# class D(B,C):
#     def go(self):
#         print("D")
#         super().go()
# d=D()
# d.go()     

# s="I'm a \"Teacher\""
# s1=str(s)
# print(s1)   # I'm a 'Teacher'
# s2=repr(s)
# print(s2)   # "I'm　a 'Teacher'"

# class Mylist:
#     '''创建一个自定义列表类，此Mylist内部用来存储信息'''
#     def __init__(self,iterable=()):
#         self.data=[x for x in iterable]
#     def __str__(self):
#         return "Mylist(%s)"% self.data
#     def __len__(self):
#         '''此方法返回的必须是整数'''
#         return   len(self.data)
#     def __abs__(self):
#         '''此方法实现把self的所有元素取绝对值后返回全为正数的自定义列表Mylist'''
#         lst=[abs(x) for x in self.data]
#         L=Mylist(lst)
#         return L

# myl =Mylist([1,-2,3,-4])
# print(myl)
# print("myl的长度是：",len(myl))    # myl.__len__()
# myl2=Mylist()
# print(myl2)

# myl3=abs(myl)
# print(myl3)


# class Mylist:
#     def __init__(self,iterable=()):
#         self.data=[x for x in iterable]
#     def __repr__(self):
#         return "Mylist(%s)"%self.data
#     def __iter__(self):
#         '''要求此方法必须返回迭代器'''
#         return Mylist_Iterator(self.data) #返回迭代器
# class Mylist_Iterator:
#     def __init__(self,data):
#         # 绑定可迭代对象的数据
#         self.data=data
#         self.cur_index=0   # 设置迭代器的起始位置
#     def __next__(self):
#         '''此方法用来实现迭代器 协议'''
#         if self.cur_index >=len(self.data):
#             raise StopIteration
#         # 拿到当前索引指向的数
#         r=self.data[self.cur_index]
#         #将索引数指向下一个数
#         self.cur_index +=1
#         return r

# L=Mylist("ABCD")
# print(L)
# for x in L:
#     print(x)


# def message_send(fn):
#     def fy(n,x): 
#         fn(n,x)
#         print("正在发送短消息给",n,'....')
#     return fy
# def pricileged_check(fn):
#    def fx(n,x):
#        print("正在验证权限验证...")
#        fn(n,x)
#    return fx
# #此装饰器用来增加短消息提醒功能
# #银行业务
# # -------一下是我写的程序-------
# @message_send
# @pricileged_check
# def save_money(name,x):
#     print(name,'存钱',x,'元')

# # @message_send
# # @pricileged_check
# # def withdraw(name,x):
# #     print(name,'取钱',x,'元')
# #--------以下是小张写的程序-------
# save_money('小王',200)
# # save_money('小赵',400)
# # withdraw('小李',500)

L=[1,2]
def f(n,lst=[]):
    lst.append(n)
    print(lst)
f(3,L)    # [1,2,3]
f(4,L)    # [1,2,3,4]
f(100)    # [100]
f(200)   # [100,200]

# 解决方法：
# 以上函数改写如下：zhong
　　　def f(n,lst=None):
         if lst is None:
            lst=[]
         lst.append(n)
         print(lst)






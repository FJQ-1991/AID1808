# class MyNumber:
#     '''自定义数字'''
#     def __init__(self,value):
#         self.data=value
#     def __repr__(self):
#         return "MyNumber(%d)"%self.data 
#     def __add__(self,other):
#         v=self.data+ other.data
#         obj =MyNumber(v)
#         return obj
#     def __sub__(self,other):
#         v=self.data - other.data
#         obj=MyNumber(v)
#         return obj
# n1=MyNumber(100)
# n2=MyNumber(200)
# n3=n1+n2
# print(n1,"+",n2,"=",n3)
# n4=n1-n2
# print(n1,"-",n2,"=",n4)

# 练习：实现两个自定义的列表相加操作
# class MyList:
#     def __init__(self,value):
#         self.data=list(value)
#     def __repr__(self):
#         return "MyList(%s)"%self.data 
#     def __add__(self,other):
#         return MyList(self.data+ other.data)
#     def __mul__(self,other):
#         return MyList(self.data * other)
#     def __rmul__(self,lhs):
#         return MyList(self.data * lhs)
#     def __iadd__(self,rhs):
#         self.data.extend(rhs.data)
#         return self 

# L1=MyList(range(1,4))
# L2 = MyList([4,5,6])
# L3=L1+L2
# print(L3)    #MyList([1,2,3,4,5,6])
# L4=L2+L1
# print(L4)    #MyList([4,5,6,1,2,3])
# L5=L1*3
# print(L5)    #MyList([1,2,3,1,2,3,1,2,3])
# L6=3*L1
# print(L6)
# L1 +=L2  #　采用　__iadd__方法

# class MyList:
#     def __init__(self,iterable=()):
#         self.data=list(iterable)
#     def __repr__(self):
#         return "MyList(%s)" % self.data
#     def __neg__(self):
#         '''重载负号运算符'''
#         L=[-x for x in self.data]    #  L=map(lambda x：－x self.data)
#         return MyList(L)
#     def __pos__(self):
#         L=[abs(x) for x in self.data]
#         return MyList(L)
# L1=MyList([1,-2,3,-4,5])
# L2= -L1
# print(L2)    # MyList([-1,2,-3,4,-5])
# L3 = +L1
# print(L3)

class MyList:
    def __init__(self,iterable=()):
        self.data =list(iterable)
    def __repr__(self):
        return "MyList(%s)"% self.data 
    def __getitem__(self,i):
        return self.data[i]
    def __setitem__(self,i,v):
        self.data[i] =v
    def __delitem__(self,i):
        del self.data[i]

L1=MyList([1,-2,3,-4,5])
x=L1[2]
print(x)  
L1[1] = 2.2
print(L1)
del L1[1]
print(L1)
x=L1[::2]    #   L1.__getitem__(slice(::2))
print(x)











# # 此示例用于示意为Dog类添加吃，睡，玩，等实例方法，以实现Ｄｏｇ对象的相应行为
# class Dog:
#     """这是一种可爱的小动物"""
#     def eat(self,food):
#         print("id为%d的"%id(self),end='')
#         print("小狗正在吃",food)
#     def sleep(self,hour):
#         print("id为%d的小狗睡了%d小时"%(id(self),hour))
#     def play(self,wanju):
#         print("id为%d的小狗正在玩%s"%(id(self),wanju))
# dog1=Dog()
# dog1.eat("骨头")
# dog2=Dog()
# dog2.eat("狗粮")
# dog1.sleep(1)
# dog2.sleep(2)
# dog1.play("球")
# dog2.play("飞盘")

# 此示例示意创建和使用实例属性
# class Dog:
#     """这是一种小动物"""
#     def eat(self,food):
#         print(self.color,"的",self.kinds,"正在吃",food)
#     # 以下让当前的小狗自己记住自己吃的是什么
#         self.last_food=food
#     def show_info(self):
#         print(self.color,"上次吃的是：",self.last_food)
# dog1=Dog()
# dog1.kinds="哈士奇"
# dog1.color="黑白相间"
# dog1.color="白色"
# print(dog1.color,"的",dog1.kinds)
# dog1.eat("骨头")

# dog2=Dog()
# dog2.color="棕色"
# dog2.kinds="藏獒"
# dog2.eat("狗粮")
# dog1.show_info()
# dog2.show_info()

#　定义一个"人"类
# class Human:
#     def set_info(self,name,age,address="不详"):
#         '''此方法用来给人对象添加"姓名","年龄"和"家庭住址"属性'''
#         self.name=name
#         self.age=age
#         self.address=address
#     def show_info(self):
#         '''显示此人的信息'''
#         print("他们的信息是:",self.name,self.age,'岁',"家庭住址:",self.address)
#     # 调用方法如下：
# s1=Human()
# s1.set_info('小张',20,'深圳市南山区')
# s2=Human()
# s2.set_info('小李',18)
# s1.show_info() #小张　２０　岁，家庭住址：深圳...
# s2.show_info() #小李　１８　岁，家庭住址：不详


#此示例示意初始化方法的定义及自动调用
# class Car:
#     def __init__(self,c,b,m):
#         self.color=c 
#         self.brand=b 
#         self.model=m 
#     def run(self,speed):
#         print(self.color,'的',self.brand,self.model,"正在以",speed,'公里／小时的速度行驶')
# a4=Car("红色",'奥迪','A4')
# a4.run(199)

# 练习：　写一个学生类　Student　类，此类用于描述学生信息
#         学生信息有：　姓名，年龄，成绩（默认为0)
#         1)为该类添加初始化方法，实现在创建对象时自动设置姓名，年龄，成绩属性
#         ２）添加set_score方法，能为对象修改成绩信息
#         ３）添加show_info方法打印学生信息
# class Student:
#     def __init__(self,name,age,score=0):
#         self.name=name
#         self.age=age
#         self.score=score
#     def set_score(self,score):
#         self.score=score
#     def show_info(self):
#         print(self.name,self.age,self.score)

# L=[]
# L.append(Student("小张",20,100))
# L.append(Student("小李",18))
# L.append(Student("小赵",19,85))
# for s in L:
#     s.show_info()
# for s in L:
#     s.show_info()
#     L[1].set_score(70)

# 此示例示意析构方法的定义和自动调用
# class Car:
#     def __init__(self,info):
#         self.info=info
#         print("汽车：",info,'对象被创建')
#     def __del__(self):
#         '''这是析构方法，形参只有一个self'''
#         print("汽车",self.info,"被销毁")
# c1=Car("BYD E6")
# del c1
# input("按回车键继续执行程序：")
# print("程序正常退出")

# class Dog:
#     pass
# dog1=Dog()
# print(dog1.__dict__)
# dog1.kinds="京巴"
# print(dog1.__dict__)

# class Dog:
#     pass
# dog1=Dog()
# print(dog1.__class__)
# dog2=dog1.__class__()
# print(dog2.__class__)

# 面向对象综合练习：
#     两个人：
#         姓名：张三，年龄：３５
#         姓名：李四，年龄：８
#     行为：
#         教别人学东西　teach
#         赚钱　work
#         借钱 borrow
#         显示自己的信息　show_info
#     事情：
#         张三　教　李四　学　python
#         李四　教　张三　学　王者荣耀
#         张三　上班赚了　1000　元钱
#         李四　向　张三　借了　200 元钱
# 打印信息：　35 岁的　张三　有钱　800 元，他学会的技能是：王者荣耀
#             ８　岁的李四　有钱　200　元，他学会的技能是：python

class Human:
    def __init__(self,name,age):
        self.name=name 
        self.age=age
        self.money=0
        self.skill=[]
    def teach(self,other,skill):
        print(self.name,"教",other.name,skill)
        other.skill.append(skill)
    def work(self,money):
        print(self.name,"上班赚了",money,'元钱')
        self.money +=money
    def borrow(self,other,money):
        if money>other.money:
            print("借钱失败")
        else:
            print(other.name,"借给",self.name,money)
            self.money +=money
            other.money -=money
    def show_info(self):
        for s in self.skill:
            print(self.age,'岁的',self.name,'有钱',self.money,'元','他学会的技能是：',s)

zhang3=Human("张三",35)
li4=Human("李四",8)
zhang3.teach(li4,"Python")
li4.teach(zhang3,"王者荣耀")
zhang3.work(1000)
li4.borrow(zhang3,200)
zhang3.show_info()
li4.show_info()


# 2018.9.25日课后练习题
# 练习：　写程序实现复制文件功能：
#     要求：１．源文件路径和目标文件路径需手动输入
#             ２．要考虑关闭文件问题
#             ３．要考虑复制超大文件问题
#             ４．要能复制二进制文件
def mycopy(src_file,dst_file):
    """src_file:源文件名
    dst_file:目标文件名"""
    fr =open(src_file,"r")  # 若要拷贝二进制文件在r后家b     若要解压超大文件，需要拆分　　fr =open(src_file,"r")   
    fw=open(dst_file,"w")  # 若要拷贝二进制文件在w后家b      　　　　　　　　　　　　　　　　fw=open(dst_file,"w")
    data=fr.read()                                           　　　　　　　　　　　　　　 # data=fr.read(4096)
    fw.write(data)
    fw.close
    fr.close　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　# 如果要考虑关闭问题　　则加入try   finally
s=input("请输入源文件路径名：")
d=input("请输入目标文件路径名：")
if mycopy(s,d):
    print("复制文件成功")
else:
    print("复制文件失败")
# def get_score():
#     n=int(input("请输入一个成绩"))
    
#     if 0<=n<=100:
#         return n
#     else:
#         return 0
# try:
#     score=get_score()
# except:
#     score=0
# print("您输入的成绩是:",score)

# 练习：　写一个函数get_age()用来获取一个人的年龄信息
# 　　此函数规定用户只能输入１～１４０之间的整数，如果用户输入的数是其它的数值，则直接触发ValueError类型的错误！
# def get_age():
#     n=int(input("请输入一个整数"))
#     if n not in range(1,141):
#         raise ValueError
#     else:
#         return n
# try:
#     age=get_age()
#     print("用户输入的年龄是",age)
# except ValueError as err:
#     print("用户输入的不是１～１４０的数字，获取年龄失败")

# 练习：　有一个集合：s={'唐僧','悟空','八戒','沙僧'}
#     用for 语句遍历所有元素如下：
#     for x in s :
#         print(x)
#     else:
#         print("遍历结束")
#     请将上面的for语句改写为while语句和迭代器实现

# s={'唐僧','悟空','八戒','沙僧'}
# a =iter(s)
# while True:
#     try:
#         x=next(a)
#         print(x)
#     except StopIteration:
#         print("遍历结束")
#         break

# 1.一个球从100米高空落下，每次落地后反弹高度为原高度的一半地，再下落，
#   　１）写程序算出皮球在第十次落地后反弹多高
#     ２）打印10次后球共经过多少米路程
# n=100
# count=1
# s=100
# while count<=10:
#     n=n/2
#     s +=n
#     count +=1
# print(n)
# print(2*s-100)

# ２．分解质因数，输入一个正整数，分解质因数，
# 　　如：输入：90　则打印：90＝2*3*3*5
#      (质因数是指最小能被原数整除的素数（不包括１)
# L=[]
# def get_zhiyin_list(x):
#     """此函数将返回包含x的所有质因数的列表"""
#     #循环查找质数，如果找到质因数就加入到L表中，直到x等于1为止
#     while x >1:
#         #以下循环只找一个质因数，找以后循环到L列表中，知道ｘ等于１为止
#         for i in range(2,x+1):
#             if x%i==0:
#                 #此时x一定是质因数
#                 L.append(i)
#                 x=int(x/i)
#                 break
#     return L
# n=int(input("请输入一个大于０的整数"))
# print(get_zhiyin_list(n))
# s='*'.join((str(x) for x in L))
# print(n,'=',s)


# 练习：　1.编写程序求１～２０的阶乘的和
# 　　　　即：1! +2! +3! +...+20!
# def jiecheng(n):
#     if n ==1:
#         return 1
#     y = n*jiecheng(n-1)
#     return y
# print(sum(map(jiecheng,range(1,20))))
# 法二
# from math import factorial as fac
# a=0
# for i in range(1,21):
#     a=a+fac(i)
# print(a)


# # 2.改写之前的学生信息管理系统
# # 　要求添加四个功能：
# # 　　| 5) 按学生成绩高－低显示学生信息　|
# #    | 6) 按学生成绩低－高显示学生信息  |
# #    | 7) 按照学生年龄高－低显示学生信息｜
# #    | 8) 按照学生年龄低－高显示学生信息｜
# L=[]
# def main(): 
#     while True:
#         print('+' + '-'* 38 + '+')
#         print("|   1) 添加学生信息　　　　　　　　　　|")
#         print("|   2) 显示学生信息　　　　　　　　　　|")
#         print("|   3) 删除学生信息　　　　　　　　　　|")
#         print("|   4) 修改学生信息　　　　　　　　　　|")
#         print("|   5) 按学生成绩高－低显示学生信息　　|")
#         print("|   6) 按学生成绩低－高显示学生信息　　|")
#         print("|   7) 按照学生年龄高－低显示学生信息　|")
#         print("|   8) 按照学生年龄低－高显示学生信息　|")
#         print("|   q) 退出　　　　　　　　　　　　　　|")
#         print('+' + '-'* 38 + '+')
#         s = input('请选择: ')
#         if s == '1':
#             input_student()
#         elif s == '2':
#             print_student(L)
#         elif s=='3':
#             shanchu(L)
#         elif s=='4':
#             xiugai(L)
#         elif s=='5':
#             chengji(L)
#         elif s=='6':
#             digao(L)
#         elif s=='7':
#             nianling_gao(L)
#         elif s=='8':
#             nianling_di(L)
#         elif s == 'q':
#             break
# def input_student():
#     while True:
#         d={}
#         global score,name
#         a =input('请输入姓名：')
#         if a=='':        
#             break
#         else:
#             d['name']=a
#         b=int(input('请输入年龄：'))
#         c=int(input('请输入成绩：'))
#         import copy
#         d['age']=b
#         d['score']=c
#         L.append(d)
#     return L
# def print_student(e):
#     m='+'+'-'*10+'+'+'-'*10+'+'+'-'*10+'+'
#     print(m) 
#     print('|'+'name'.center(10)+'|'+'age'.center(10)+'|'+'score'.center(10)+'|')
#     print(m) 
#     for x in L:
#         n='|'+x['name'].center(10)+'|'+str(x['age']).center(10)+'|'+str(x['score']).center(10)+'|'
#         print(n) 
#         print(m)

# def shanchu(f):
#     i=0
#     while i<len(L):
#         print(L[i])
#         n=input("请选择yes或no: ")
#         if n == 'yes':
#             L.remove(L[i])
#         if n== 'no':
#             i +=1
#             continue
#     return L 
# def xiugai(j):
#     for x in L:
#         print(x)
#         n=input("请选择yes或no: ")
#         if n == 'yes':
#             L.remove(x)
#             x=input_student()
#         if n == 'no':
#             continue
#     return L
# def chengji(L):
#     def get_score(d):
#         return d['score']
#     L=sorted(L,key=get_score,reverse=True)
#     print_student(L)


# def digao(L):
#     L=sorted(L,key=lambda d:d['score'])
#     print_student(L)

# def nianling_gao(L):
#     L=sorted(L,key=lambda d:d['age'],reverse=True)
#     print_student(L)

# def nianling_di(L):
#     L=sorted(L,key=lambda d:d['age'])
#     print_student(L)
# main()



# 3.已知有列表：
# 　　L=[[3,5,8],10,[[13,14],15,18],20]
#   1) 写个函数print_list(lst)  打印出所有的数字，即：
#   　print_list(L)　　＃　打印３　５　８　１０　１３．..
# d=[]
# L=[[3,5,8],10,[[13,14],15,18],20]
# def print_list(L):
    
#     for x in L:
#         if type(x) is list:
#             print_list(x)
#         else:
#             print(x,end=' ')
#             d.append(x)
#     return d
# print_list(L)

#   2)写一个函数sum_list(lst) 返回这个列表中所有数字的和
#   　print(sum_list(L))　　＃１０６
#   注：　type(x) 可以返回一个变量的类型，如：
#   　>>>type(20) is int  # True
#   >>> type([1,2,3]) is list # True
# L=[[3,5,8],10,[[13,14],15,18],20]
# def sum_list(L):
#     i=0
#     s=print_list(L)
#     for x in s:
#         i +=x
#     print()
#     return i

# print(sum_list(L))


# １．编写函数fun，其功能是计算下列多项式的和
#     f(n) = 1/0!+1/1! +1/2! +1/3! +.....+1/n!
# def fun(n):
#     a=0
#     from math import factorial
#     for x in range(n+1):
#         s=factorial(x)
#         a +=1/s
#     return a
# n=int(input("请输入一个整数"))
# print(fun(n))

# 2.　写一个程序，以电子时钟格式显示时间：
# 　　　格式为：　HH:MM:SS    如：１５：５８：２６
# while True:
#     import time
#     cur_second=time.localtime()
#     (a,b,c)=cur_second[3:6]
#     time.sleep(1)
#     print(a,':',b,':',c,end='\r')

# ３．编写一个闹钟程序，启动时设置定时时间，到时间后打印一句"时间到",然后退出程序
# a=int(input("请设置闹钟时间：时："))
# b=int(input("请设置闹钟时间：分："))
# c=int(input("请设置闹钟时间：秒："))
# while True:
#     import time
#     d=time.localtime()
#     if d[3:6]==(a,b,c):
#         print("时间到")       
#         break
#     print(d[3],':',d[4],':',d[5], end='\r')
#     time.sleep(1)
    

# def mysum(n):
#         print("正在计算１＋２＋３．．＋",n,'的和')
    
# def myfac(n):
#     print("正在计算%d!..."%n)
    
# name1 ="Audi"
# name2 ="Tesla"
#     # print("mymod模块被加载")    注：mymod是文件名
#     # 示例：此示例示意导入自定义模块并调用其中的函数
# import day919
# day919.mysum(100)
# print(day919.name1)
# day919.myfac(200)
# # from mymod import myfac as fac
# # fac(6)
# print(day919.name2)
# # from mymod import*
# # mysum(200)
# # print(name2)

# 练习：　猜数字游戏：
# 　　　　　　随机生成一个0~100之间的整数，用变量x绑定让用户输入一个数y,输出猜数字的结果
# 　　　　　　　１）如果y等于生成的数x，则提示"恭喜您猜对了",并退出程序
#         ２）如果y大于x,则提示"您猜大了",然后继续猜下一次
#         ３）如果y小于x，则提示"您猜小了",....
#         　　　直到猜对为止，最后显示用户猜数字的次数后退出程序
# import random
# x=int(random.uniform(1,100))
# count=0
# while True:
    # y=int(input("请输入一个整数"))
#     count +=1
#     if y==x:
#         print("恭喜您猜对了")
#         break
#     elif y>x:
#         print("您猜大了")
#     elif y<x:
#         print("您猜小了")
# print("您共猜了%d次"%count)

# 练习：　１．模拟斗地主发牌，扑克牌５４张
# 　　　　　　花色：　黑桃（'\u2660'),梅花（'\u2663'),红桃（'\u2665')
#         方块（'\u2666')
#       数字：　A2-10JQK　　大王，小王
#       三个人，每人发１７张牌，底牌留三张
#       　　输入回车，打印第１个人的１７张牌
#       　　输入回车，打印第２个人的１７张牌
#       　　输入回车，打印第３个人的１７张牌
#       　　输入回车，打印３张底牌

def main():
    L=[]
    L1=['A','2','3','4','5','6','7','8','9','10','J','Q','K']
    for x in L1:
        a=x+'\u2660'
        L.append(a)
        b=x+'\u2663'
        L.append(b)
        c=x+'\u2665'
        L.append(c)
        d=x+'\u2666'
        L.append(d)
    L=L+['大王','小王']
    return L
def suiji(L,n):
    import random as r
    r.shuffle(L)
    pai=r.sample(L,17)
    print("第%d个人的牌是:"%n,end=' ')
    for y in pai:
        print(y,end=' ')
        L.remove(y)
    print()
    return L
def huiche(L,m):
    n=input()
    if not n:
        suiji(L,m)
L=main()
huiche(L,1)
huiche(L,2)
huiche(L,3)
s=input()
if not s:
    print("底牌是:",end=' ')
    for i in L:
        print(i,end=' ')
    print()
# ２．修改学生信息管理程序，拆分为模块
# 　　　要求：　１．主事件循环放在main.py中
# 　　　　　　　２．show_menu函数放在menu.py中
#         　　３．与学生操作相关的函数放在student_info.py中



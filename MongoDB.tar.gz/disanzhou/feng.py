class Dog:
    pass
dog1 = Dog()
print(dog1.__class__)
dog2 = dog1.__class__()
print(dog2.__class__)
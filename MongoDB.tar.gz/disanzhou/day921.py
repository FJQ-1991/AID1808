# 练习：
#     写一个生成器函数　myeven(start,stop)
#     用来生成从start开始到stop结束区间内的一系列偶数（不包括stop)
# def myeven(start,stop):
#     for i in range(start,stop):
#         if i%2 !=0:
#             pass
#         else:
#             yield i
# evens=list(myeven(10,20))
# print(evens)  # [10,12,14,16,18]
# for x in myeven(5,10):
#     print(x) #6 8
# L=[x for x in myeven(0,10)]
# print(L)  # [0,2,4,6,8]

# 练习：已知有列表：L=[2,3,5,7,10,15]
#     1)写一个生成器函数，让此函数能动态提供数据，数据为原列表的数字的平方＋１
# L=[2,3,5,7,10,15]
# def myeven(L):
#     for x in L:
#         yield x**2+1
# s=list(myeven(L))
# print(s)
# ２）写一个生成器表达式，让此表达式能动态提供数据，数据依旧为原列表数字的平方＋１
# gen = list((x**2+1 for x in L))
# print(gen)
# ３）生成一个列表，此列表内的数据为原列表的数字的平方＋１
# gen =[(x**2+1 for x in L)]
# print(gen)

# 练习：写一个生成器函数，给出开始值begin,和终止值end,此生成器函数生成begin~end范围内的全部素数（不包括end)
# def prime(begin,end):
#     for x in range(begin,end):
#         for y in range(2,x):
#             if x%y==0:
#                 break
#         else:
#             yield x
# L=list(prime(10,20))
# print(L)   #[11,13,17,19]

# 练习：写一个程序，读入任意行的文字，当输入空行时结束输入
#     打印带有行号的输入结果
#     如：请输入：tarena<回车>
#         请输入：china<回车>
#         请输入：holiday<回车>
#         请输入:<回车>
#     输出如下：
#     　第１行：tarena
#       第２行：china
#       第３行：holiday
# L=[]
# while True:
#     n=input('请输入：')
#     if not n:
#         break
#     else:
#         L.append(n)
# for x in enumerate(L,1):
#     print("第%d行:%s" %x)

# 练习：有一个bytearray字节数组
#     ba=bytearray(b'a1b2c3d4')
#     如何得到字节串'1234'和'abcd'
#     将上述字节数组改为：
#     ba=bytearray(b'A1B2C3D4')
ba=bytearray(b'a1b2c3d4')
c=ba[::2]
c=bytes(c)
print(c)
d=ba[1::2]
d=bytes(d)
print(d)
ba[::2]=bytearray(b'ABCD')
ba=bytes(ba)
print(ba)
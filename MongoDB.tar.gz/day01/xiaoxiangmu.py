# １．已知有两个等长的列表
# 　　　　　list1=[1001,1002,1003,1004]
#         list2=['Tom','Jerry','Spike','Tyke']
#       写程序生成如下字典：
#       　｛'Tom':1001,'Jerry':1002,'Spike':1003,'Tyke':1004}

# list1=[1001,1002,1003,1004]
# list2=['Tom','Jerry','Spike','Tyke']
# d={}
# for x in range(len(list1)):
#     d[list2[x]]=list1[x] 
# print(d)

#     2.任意输入多个学生的姓名，年龄，成绩，每个学生信息存入一个字典中，然后再放入列表中（每个学生信息需要手动输入）
#     　　　如：　　请输入姓名：　tarena
#               请输入年龄：１５
#               请输入成绩：９９
#               请输入姓名：name2
#               请输入年龄：２２
#               请输入成绩：１００
#               请输入姓名：<直接回车结束输入>
#         在程序内部生成如下列表：
#       L=[{'name':tarena,'age',:15,'score':99},{'name':name2,'age':22,'score':100}]
#        1)打印出上述列表
#        ２)以下表格的形式打印出上述信息
# 　　　+-------------+-----------+----------+
#      |   name      |   age     |   score  |
#      +-------------+-----------+----------+
#      |   tarena    |   15      |    99    |
#      |    name2    |   22      |    100   |
#      +-------------+-----------+----------+
# 1.
# d={}
# L=[]
# m='+'+'-'*10+'+'+'-'*10+'+'+'-'*10+'+'
# while True:
#     a =input('请输入姓名：')
#     if a=='':         # if not n:   同样表示姓名为空时结束
#         break
#     else:
#         d['name']=a
#     b=int(input('请输入年龄：'))
#     c=int(input('请输入成绩：'))
#     import copy
#     d['age']=b
#     d['score']=c
#     d1=copy.deepcopy(d)
#     L=L+[d1]

# print(L)
# print(m) 
# print('|'+'name'.center(10)+'|'+'age'.center(10)+'|'+'score'.center(10)+'|')
# print(m) 
# for x in L:
#     n='|'+x['name'].center(10)+'|'+str(x['age']).center(10)+'|'+str(x['score']).center(10)+'|'
#     print(n) 
#     print(m)

# 1.　写一个函数isprime(x) 判断x是否是素数，如果是素数返回True,否则返回False
# def isprime(x):
#     if x <2:
#         return False
#     for j in range(2,x):
#         if x%j==0:
#             return False
#     return True

# print(isprime(4))   #False
# print(isprime(5))   #True

# 2.写一个函数prime_m2n(m,n) 返回从m开始，到n结束的范围内的素数（不包含n），返回这些素数的列表，并打印
# 如：　　
# def prime_m2n(m,n):
#     L=[]
#     if m>n:
#         m=n 
#     for x in range(m,n):
#         for y in range(2,x):
#             if x%y == 0:
#                 break
#         else:
#             L.append(x)
#     return L

# L = prime_m2n(5,10)
# print(L)   #[5,7]

# 3.写一个函数primes(n)  返回指定范围n以内的素数（不包含n）的全部素数的列表，并打印这些素数
# 　　L=primes(n)
#    print(L)  #[2,3,5,7]
#    1)打印100以内的全部素数
#    2)200以内的全部素数的和

# def primes(n):
#     L=[]
#     for x in range(2,n):
#         for y in range(2,x):
#             if x%y==0:
#                 break
#         else:
#             L.append(x)
#     return L

# L=primes(100)
# print("100以内的素数有:",L)
# L=primes(200)
# print("200以内的全部素数的和为:",sum(L))

# 4.改写之前的学生信息管理程序：
# 　　改为用两个函数实现
#     1.写函数input_student()来获取学生信息，
# 　　　当输入姓名为空时结束输入，形成字典组成的列表并返回
# 　　　2.写函数print_student(L) 将上述函数得到的打印成为表格显示
#    如：

def input_student():
    d={}
    L=[]
    while True:
        a =input('请输入姓名：')
        if a=='':         # if not a:   同样表示姓名为空时结束
            break
        else:
            d['name']=a
        b=int(input('请输入年龄：'))
        c=int(input('请输入成绩：'))
        import copy
        d['age']=b
        d['score']=c
        d1=copy.deepcopy(d)
        L=L+[d1]
    return L
L=input_student()
print(L)
def print_student(L):
    m='+'+'-'*10+'+'+'-'*10+'+'+'-'*10+'+'
    print(m) 
    print('|'+'name'.center(10)+'|'+'age'.center(10)+'|'+'score'.center(10)+'|')
    print(m) 
    for x in L:
        n='|'+x['name'].center(10)+'|'+str(x['age']).center(10)+'|'+str(x['score']).center(10)+'|'
        print(n) 
        print(m)
print_student(L)




# n=input('请输入字符串')
# i=0
# for x in n:
#     if x=='a':
#         i +=1
# print(" 'a'的个数是:",i)

# a=0
# for j in n:
#     if j==' ':
#         a +=1
# print("空格个数是：",a)

# for x in range(1,21):
#     print(x,end=' ')


# for x in range(1,21):
#     print(x,end=' ')
#     if x%5==0:
#         print()

# for x in range(1,101):
#     if x * (x+1)%11==8:
#         print(x)
 
# i=0
# n=input("请输入字符串:")
# for x in n:
#     x=ord(x)
#     if x>127:
#         i +=1
# print(i)
    
# i=6
# for x in range(1,i):
#     print(x,i)
#     i -=1

# for x in range(4,0,-1):
#     print(x)
# else:
#     print('循环结束后x的值是:',x)

# 写一个程序，打印２６个大写英文字母和２６个小写英文字母
# ABCD...XYZabcd...XYZabcd

# A=ord('A')
# Z=ord('Z')
# for feng in range(A,Z+1):
#     feng=chr(feng)
#     print(feng,end='')
# a=ord('a')
# z=ord('z')
# for feng in range(a,z+1):
#     feng=chr(feng)
#     print(feng,end='')
# print()

# for x in range(5):
#     if x ==2:
#         continue
#     print(x)
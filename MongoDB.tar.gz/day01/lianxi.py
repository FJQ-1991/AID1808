# 练习：
# 　　1.输入一个字符串，把输入的字符串中的空格全部去掉（包括字符串中间的空格）
# 　　　1)打印原字符串及长度
# 　　　2)打印处理后的字符串及长度
# 　　2.写程序，输入三行文字，让这三行文字在一个方框内居中显示
# 　　　如：　　请输入：hello!
#             请输入:I'm studing python!
#             请输入:I like python!
#     打印如下：
#     +----------------------+
#     |      hello!          |
#     |  I'm studing python! |
#     |     I like python!   |
#     +----------------------+
#     注：不要输入中文
# 一：
# s=input("请输入字符串：")
# a=s.replace(' ','')
# # 1.
# print(s,len(s))
# # 2.
# print(a,len(a))
# 二：
# a=input("请输入第一行文字")
# b=input('请输入第二行文字')
# c=input("请输入第三行文字")
# s=max(len(a),len(b),len(c))
# print('+'+'-'*(s+4)+'+')
# print("|"+a.center(s+4)+"|")
# print("|"+b.center(s+4)+"|")
# print("|"+c.center(s+4)+"|")
# print('+'+'-'*(s+4)+'+')



#  1.写一个函数get_chinese_char_count(s) 函数，此函数实现的功能是给定一个字符串，返回这个字符串中中文字符的个数
# def get_chinese_char_count():
#     s=input("请输入中英文混合的字符串:")  
#     i=0 
#     for x in s:
#         if ord(x)>127:
#             i +=1
#     return i
# print("您输入的中文字符的个数是:",get_chinese_char_count())

# 2.定义两个函数：
# 　　　sum3(a,b,c) 用于返回三个数的和
# 　　　pow3(x) 用于返回x的三次方（立方）
# 用以上函数计算：
# 　　１）计算１的立方＋２的立方＋３的立方
# 　　2)计算１＋２＋３的和的立方
# 　　　　即：1**3+2**3+3**3和(1+2+3)**3

# a=int(input("请输入第一个数"))
# b=int(input("请输入第二个数"))
# c=int(input("请输入第三个数"))
# d=int()
# def sum3(a,b,c):
#     return a+b+c
# def pow3(x):
#     d =x**3
#     return d
# print('1的立方+２的立方+3的立方为：',sum3(pow3(a),pow3(b),pow3(c)))
# print("1+2+3的和的立方为：",pow3(sum3(a,b,c)))

# 九九乘法表
# for x in range(1,10):
#     for j in range(1,x+1):
#         print(j,'*',x,'=',j*x ,end='  ')
#     print()


# def myfun1(a,b,c):
#     print("a的值是：",a)
#     print("b的值是：",b)
#     print("c的值是：",c)

# s="ABC"
# myfun1(*s)
# d={'c':33,'b':22,'a':11}
# myfun1(**d)

# def info(name,age=1,address='不详'):
#     print("我叫:",name,"我今年:",age,"岁","家庭地址:",address)
# info("张飞",30,"中原")
# info("Tarena",10)
# info("赵云") 

# 写一个函数，myadd,此函数可以计算两个数，三个数及四个数的和:
#   如：
# def myadd(a,b,c=0,d=0):
#     e=a+b+c+d
#     return e

# print(myadd(10,20))
# print(myadd(100,200,300))
# print(myadd(1,2,3,4))

# def fn(a,lst=[]):          
#     lst.append(a)
#     print(lst)
# L =[1,2,3,4]
# fn(5,L)     #[1,2,3,4,5]
# fn(6,L)     # [1,2,3,4,5,6]
# fn(1.1)     #  [1,1]
# fn(2.2)     # [2.2]

# def func(*args):
#     print('用户传入的参数个数是：',len(args))
#     print('args=',args)
# func()
# func(1,2,3)
# func(1,2,3,'aaa','bbb','ccc')

# 写一个函数，mysum 可以传入任意个数字的实参，此函数调用将返回实参的和
# 　　如：
# def mysum(*args):
#     return sum(args)

# print(mysum())
# print(mysum(1,2,3,4,5,6))

# 写一个函数min_max(...)函数,
#   此函数至少要传入一个参数，并返回全部这些数数的最小值，最大值（形成元组，最小在前，最大在后）
#   调用此函数，得到最小值和最大值并打印出来
#   如
# def min_max(*args):
#     a=b=args[0]
#     for j in args:
#         if a>j:
#             a=j
#         if b<j:
#             b=j
#     return (a,b)        
# print(min_max(10,20,30))   #(10,30)
# x,y = min_max(8,6,4,3,9,2,1)
# print("最小值是：",x)
# print("最大值是:",y)
# print(min_max())   #没有实参报错

# def func(**kwargs):
#     print("关键字传参的个数是：",len(kwargs))
#     print("kwargs=",kwargs )

# func(name='tarena',age=15)
# func(a=1,b="BBBB",c=[2,3,4],d=True)

# def fn(a,b,*args,c,**kwargs):
#     print(c)
#     print(args)
# fn(100,200,300,400,c=100,*"AB",**{'d':"D"})
# #     可以接收任意位置传参和关键字传参的函数：
# # def fn(*args,**kwargs):
# #     pass

# 写一个myrange函数，参数可以传入１～３个，实际含义与range函数相同
# 　此函数返回符合range(...)函数的列表
# def myrange(a,b=None,c=None):
# #     if b is None:
# #         start=0
# #         stop=a
# #     else:
# #         start=a
# #         stop=b
# #     if c is None:
# #         step=1
# #     else:
# #         step=c
#     L=[]
#     for x in range(a,b,c):
#         L.append(x)
#     return L

# L=myrange(4)
# print(L)
# L=myrange(4,6)
# print(L)
# L=myrange(1,10,3)
# print(L)

# a=100
# b=200
# def fn(c):
#     d=400
#     print(a,b,c,d)  # 有错，此时a变量还不存在
#     # a=500             # 用来创建一个局部变量
#     print(a,b,c,d)    # 500,200,300,400

# fn(300)
# print('a=',a)     #  100
# print('b=',b)



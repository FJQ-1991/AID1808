# 方法一
# s=10
# fmt="%"+str(s)+"s"
# print(fmt%"冯进权")
# 方法二
# a=10
# fmt="%%%ds"%a
# print(fmt%"冯进权")


# begin=int(input('请输入开始值'))
# end = int(input('请输入结束值'))
# L=[x for x in range(begin,end) if x%2==0]
# print(L)


# L=[]
# while True:
#     n=int(input('请输入整数'))
#     if n==0:
#         break
#     else:
#         L.append(n)
# L1=[x for x in L if x>0]
# L2=[x for x in L if x<0]
# print('原列表为：',L)
# print('正数列表L1为：',L1)
# print('负数列表L2为：',L2)

# 1.已知有一个字符串：
# 　s='100,200,300,500,800'
# 将其转化为数字组成的列表，列表内部为整数：
# L=[100,200,300,500,800]
# s='100,200,300,500,800'
# L=[int(x) for x in s.split(',')]
# print(L)
# L=[]
# s='100,200,300,500,800'
# s.split(s)
# L=s[:]
# print(L)

# 2.用列表推导式生成如下列表：
# 　L=[1,4,7,10,....100]

# L=[x for x in range(1,101,3)]
# print(L)

# 3.用列表推导式生成如下列表（思考题）
# [[1,2,3],[4,5,6],[7,8,9]]
# # 方法一
# L=[[x,x+1,x+2] for x in  range(1,8,3)]
# print(L)
# # 方法二
# L=[[y for y in range(x,x+3)] for x in  range(1,8,3)]
# print(L)

# 1.有一些数存于列表中，如：
# Ｌ＝[1,3,2,1,6,4,2,...98,82]
#   1) 将列表Ｌ中出现的数字存入到另一个列表L2中，
#   　　　要求：重复出现多次的数字存在L２中保留一份（去重）
#   ２)　将列表中出现两次的数字存于列表Ｌ３中，在L3中只保留一份

# L=[]
# L2=[]
# L3=[]
# while True:
#     n=int(input("请输入一些整数"))
#     if n==0:
#         break
#     else:
#         L.append(n)
# for x in L:
#     if x not in L3:
#         L2.append(x)
#     if L.count(x)==2:
#         if x not in L3:
#             L3.append(x)
    
            
            
# print("原列表为：",L)
# print("在原列表中大于两次的为：",L2)
# print("在原列表中出现两次的为：",L3)

# ２．计算除１００以内的全部素数，将这些素数存于列表中，然后打印出列表中的这些素数
# L=[]
# for x in range(2,100):
#     for j in range(2,x):
#         if x%j ==0:
#             break
#     else:
#         L.append(x)
# print("100以内的素数有：",L)

# ３．生成前４０个斐波那契数列中的数
# 　　　１　１　２　３　５　８　１３　２１
# 要求　将这些数保存与列表中，打印这些数

# n1=1
# n2=1
# n3=2
# L=[1,1]
# while len(L)<40:
#     n3=n1+n2
#     n1=n2
#     n2=n3
#     L.append(n3)
# print(L)
# print("L列表中共有",len(L),"个数")

# 练习：　　创建一个字典：
# d = {'name':'tarena','age'：15}
# 为此字典添加地址（address)键，对应的值为'北京是海淀区',结果如下：
# 　　　　　　　　　　d = {'name':'tarena','age':15,'address':'北京市海淀区'}
# d = {'name':'tarena','age':15}
# d['address']='北京市海淀区'
# print(d)
# 练习：　输入一段字符串，打印出这个字符串中出现过的字符及出现过的次数
# 　　如：输入：ABCDABCABA
# 打印：a:4次
# 　　　b:3次
# 　　　d:1次
#      c:2次
# 法一
# n=input('请输入字符串')
# d={}
# for x in n:
#     if x in d:
#         d[x]=d[x]+1
#     else:
#         d[x]=1
# print(d)
# 法二
# for k,v in d.items():
#     print(k,':',v,'次')
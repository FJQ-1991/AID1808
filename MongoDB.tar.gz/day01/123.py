# 　1.看懂下面的程序在做什么
# def fx(f,x,y):
#     print(f(x,y))
# fx((lambda a,b:a+b),100,200)    # 100+200
# fx((lambda a,b:a**b),3,4)  # 3**4

# 2.给出一个整数n，写一个函数来计算
#  　1+2+3+4+...+n 的值并返回结果
#  　要求用函数来做
#  如：　
# def mysum(n):
#     y=0
#     for x in range(1,n+1):
#         y +=x
#     return y
# print(mysum(100))   #5050
# print(mysum(10))   #55

# 3.给出一个整数n，写一个函数来计算n!(n的阶乘)
#  　　n! = 1*2*3*4...*n
# def myfac(n):
#     y=1
#     for x in range(1,n+1):
#         y *=x
#     return y
# print(myfac(5))    #120

# 4.给出一个整数n，写一个函数来计算1+2**2+3**3+...+n**n的和
#  　　　(n给一个小点的数)
# def feng(n):
#     y=1
#     for x in range(2,n+1):
#         y += x**x
#     return y
# print(feng(4))

# 5.写程序打印杨辉三解（只打印六层）
#        1
#       1 1
#      1 2 1
#     1 3 3 1
#    1 4 6 4 1
#   1 5 10 10 5 1
# y=[0,1]
# for a in range(x):
#     y[a]=y[a-1]+y[a-2]
#     print(y[a],end=' ')
# a=int(input('请输入一个整数：'))
# a=a-1
# def yanghui():
#     for y in range(a+1):
#         if y==0:
#             print(' '*(a+1),end='')
#         for i in range(y+1):
#             m=jiecheng(y)//(jiecheng(i)*jiecheng(y-i))
#             print(m,end=' ')
#         print()
#         print(' '*(a-y),end='')
# def jiecheng(s):
#     b=1
#     for i in range(1,s+1):
#         b=b*i
#     return b
# yanghui()
#步骤：　第一步，制造相应的列表
def get_net_list(L):
      # 用给定的一行Ｌ，返回下一行
      # 如L为[1,2,1] 则返回[1,3,3,1]
    rl=[1]   # 最左边的１
    rl.append(1)    # 最右边的１
    return rl
      # 算中间的数字（循环获取从０开始的索引）
    for i in range(len(L)-1):
        v = L[i]+L[i+1]
        rl.append(v)
    #第二步，生成全部的行放到一个整体的列表rl中，并返回
def yh_list(n):   # n为行数
    # 如果n为３最终返回的列表是：
    # [[1],[1,1],[1,2,1]]
    rl =[ ]
    L=[1]
    while len(rl)<n:
        rl.append(L)# 加入当前行
        L=get_net_list(L)  # 计算出下一行准备加入
    return rl
# 第三步，把杨辉三角的列表列表转为字符串列表
# 如果给定的列表是[[1],[1,1],[1,2,1]]
 #返回['1','1 1','1 2 1']
def get_yh_string(L):
    rl=[]
    for line in L:
        # line =[1,2,1] -> s='1 2 1'
        str_lst=[str(x) for x in line]
        # str_lst = ['1','2','1']
        s=' '.join()   #s='1 2 1'
        rl.append(s)
    return rl
# 打印杨辉三角
def print_yh_triang(L):
    # L = ['1','1 1','1 2 1']
    max_len=len(len(L[-1]))
    for s in L:
        print(s.center(max_len))
L=yh_list(6)
SL=get_yh_string(L)
print_yh_triangle(SL)
# 6.实现带界面的学生信息管理系统的项目
#  　　+----------------------+
#     |   1)添加学生信息       |
#     |   2)显示学生信息       |
#     |   3)删除学生信息       |
#     |   4)修改学生成绩       |
#     |　　q) 退出            |
#     +----------------------+

#     (要求：用函数来实现，每个功能写一个函数写之相对应)
# L=[]
# def main(): 
#     infos=[]
#     while True:
#         print('+' + '-'* 25 + '+')
#         print("|     1) 添加学生信息     |")
#         print("|     2) 显示学生信息     |")
#         print("|     3) 删除学生信息     |")
#         print("|     4) 修改学生信息     |")
#         print("|     q) 退出　　　　     |")D
#         print('+' + '-'* 25 + '+')
#         s = input('请选择: ')
#         if s == '1':
#             input_student()
#         elif s == '2':
#             infos=print_student(L)
#         elif s=='3':
#             infos=shanchu(L)
#         elif s=='4':
#             infos=xiugai(L)
#         elif s == 'q':
#             break
# def input_student():
#     while True:
#         d={}
#         a =input('请输入姓名：')
#         if a=='':        
#             break
#         else:
#             d['name']=a
#         b=int(input('请输入年龄：'))
#         c=int(input('请输入成绩：'))
#         import copy
#         d['age']=b
#         d['score']=c
#         L.append(d)
#     return L
# def print_student(e):
#     m='+'+'-'*10+'+'+'-'*10+'+'+'-'*10+'+'
#     print(m) 
#     print('|'+'name'.center(10)+'|'+'age'.center(10)+'|'+'score'.center(10)+'|')
#     print(m) 
#     for x in L:
#         n='|'+x['name'].center(10)+'|'+str(x['age']).center(10)+'|'+str(x['score']).center(10)+'|'
#         print(n) 
#         print(m)
# def shanchu(f):
#     i=0
#     while i<len(L):
#         print(L[i])
#         n=input("请选择yes或no: ")
#         if n == 'yes':
#             L.remove(L[i])
#         if n== 'no':
#             i +=1
#             continue
#     return L 
# def xiugai(j):
#     for x in L:
#         print(x)
#         n=input("请选择yes或no: ")
#         if n == 'yes':
#             L.remove(x)
#             x=input_student()
#         if n == 'no':
#             continue
#     return L

# main()








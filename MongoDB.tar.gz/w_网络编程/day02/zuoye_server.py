from socket import *
sockfd=socket(AF_INET,SOCK_STREAM)
sockfd.bind(('0.0.0.0',9999))
sockfd.listen(3)
print("waiting for connect...")
confd,addr=sockfd.accept()
print("连接到：",addr)
f=open('/home/tarena/aid1808/linux/w_网络编程/day02/recv.jpg','wb')
while True:
    data=confd.recv(1024)
    if not data:
        break
    f.write(data)
    
f.close()
confd.close()
sockfd.close()

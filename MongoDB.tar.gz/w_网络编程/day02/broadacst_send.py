from socket import *
from time import sleep 
# 目标地址
dest = ('172.88.17.255',9999)
s = socket(AF_INET,SOCK_DGRAM)
# 设置可以发送接收广播
s.setsockopt(SOL_SOCKET,SO_BROADCAST,1)
s.bind(('0.0.0.0',9999))
while True:
    sleep(2)
    s.sendto("这个老师真傻逼！".encode(),dest)
s.close()
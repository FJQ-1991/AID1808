from socket import *
sockfd=socket()
sockfd.connect(('127.0.0.1',9999))
f=open('send.jpg','rb')
while True:
    data=f.read(1024)
    if not data:
        break
    sockfd.send(data)
f.close()
sockfd.close()


import socket
ver = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
ver.bind(("0.0.0.0",9999)) 
ver.listen(10)
while True:
    connfd,addr = ver.accept()
    print("客户端",addr,"连接")
    file_data = connfd.recv(2048)
    file_data = file_data.decode()
    try:
        with open("/home/tarena/aid1808/linux/w_网络编程/" +file_data,"rb") as file:
            f = file.read(2048)
            if f:
                connfd.send(f)
            else:
                print(file_data,'传输成功')
                break
    except Exception as e:
        print("传输异常",e)
connfd.close()
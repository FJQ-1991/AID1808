import socket
fd = socket.socket()
# fd.bind(("",8888))
fd.connect(("0.0.0.0",9999))
f = input("请输入要下载的文件:\n")
fd.send(f.encode())
try:
    with open("/home/tarena/aid1808/linux/w_网络编程/" + f,'wb') as file:
        while True:
            file_data = fd.recv(2048)
            if file_data:
                file.write(file_data)
            else:
                break
except Exception as e:
    print(fd,'下载成功')
fd.close()